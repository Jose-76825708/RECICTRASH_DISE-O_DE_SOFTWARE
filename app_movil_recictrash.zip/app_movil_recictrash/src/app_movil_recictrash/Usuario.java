package app_movil_recictrash;


public class Usuario {
    private String apellidos;
    private String nombres;
    private String correo;
    private String contrasena;
    private String telefono;
    private String rol;
    
    public Usuario(){}
    
    public Usuario(String apellidos , String nombres, String correo,String contrasena,String telefono){
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.correo = correo;
        this.contrasena = contrasena;
        this.telefono = telefono;
    }
    
    public String getApellidos() {return apellidos;}
    public void setApellidos(String apellidos) {this.apellidos = apellidos;}
    
    public String getNombres() {return nombres;}
    public void setNombres(String nombres) {this.nombres = nombres;}
    
    public String getCorreo() {return correo;}
    public void setCorreo(String correo) {this.correo = correo;}
    
    public String getContrasena() {return contrasena;}
    public void setContrasena(String contrasena) {this.contrasena = contrasena;}
    
    public String getTelefono() {return telefono;}
    public void setTelefono(String telefono) {this.telefono = telefono;}
    
    public String getRol() {return rol;}
    public void setRol(String rol) {this.rol = rol;}
}
